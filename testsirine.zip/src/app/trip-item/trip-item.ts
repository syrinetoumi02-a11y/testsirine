import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  imports: [],
  selector: 'toum-trip-item',
  styleUrl: './trip-item.css',
  templateUrl: './trip-item.html',
})
export class TripItem {
  @Input() trip!: Trip;
  @Output() reserver = new EventEmitter<number>();
  reserver(): void {
    if (this.trip.nbPlaces > 0) {
      this.reserver.emit(this.trip.id);
    }
  }
}
