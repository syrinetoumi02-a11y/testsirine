import { Component, signal } from '@angular/core';
import { Trip } from '../models/trip';
import { TripItem } from '../trip-item/trip-item';

@Component({
  imports: [TripItem],
  selector: 'toum-trip-list',
  styleUrl: './trip-list.css',
  templateUrl: './trip-list.html',
})
export class TripList {
      voyages = signal<Trip[]> ([
    { id:587, destination: "Bali",photo: "photos/bali.jpg", price: 7800, nbDays: 11, nbPlaces: 12, visa: true },
    { id:183, destination: "Turquie",photo: "photos/turquie.jpg", price: 4300, nbDays: 7, nbPlaces: 8, visa: false },
    { id:25, destination: "Egypte",photo: "photos/egypte.jpg", price: 4100, nbDays: 14, nbPlaces: 15, visa: true },
    { id:399, destination: "Algérie",photo: "photos/algerie.jpg", price: 850, nbDays: 9, nbPlaces: 11, visa: false }
  ]);
  nbVoyagesDispo(): number {
    return this.voyages().filter(
      v=> v.nbPlaces > 0
    ).length;
  }
  reserver(id: number): void {
    this.voyages.update( 
      liste.map(
        v=>v.id===id && v.nbPlaces>0 ? {...v, nbPlaces: v.nbPlaces-1} : v
      )
    );
}
joursMinimum(): number {
    return this.voyages().reduce(
      (min, v) => v.nbDays < min ? v.nbDays : min,
      Number.MAX_VALUE
    );
  }
  

